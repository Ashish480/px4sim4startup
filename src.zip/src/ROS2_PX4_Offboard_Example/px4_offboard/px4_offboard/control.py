#!/usr/bin/env python3
import sys
import time
import math
import select
import threading

import geometry_msgs.msg
import rclpy
from rclpy.node import Node
import std_msgs.msg
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy
# Import PX4's message type instead of nav_msgs
from px4_msgs.msg import VehicleOdometry, VehicleStatus
# Import directly from transforms3d to avoid the problematic tf_transformations
import transforms3d.euler
import transforms3d.quaternions

if sys.platform == 'win32':
    import msvcrt
else:
    import termios
    import tty

msg = """
This node takes keypresses from the keyboard and publishes them
as Twist messages.
Using the arrow keys and WASD you have Mode 2 RC controls.
W: Up
S: Down
A: Yaw Left
D: Yaw Right
Up Arrow: Pitch Forward
Down Arrow: Pitch Backward
Left Arrow: Roll Left
Right Arrow: Roll Right

Press SPACE to arm/disarm the drone manually
Press 'p' to toggle circular flight mode around the house (start/stop)
    - This will automatically arm the drone
    - The drone will first move to 10m height (assumed height without position data)
    - Then it will rotate in a continuous elliptical path
Press 'e' to toggle elliptical flight mode (start/stop)
    - Similar to circular mode, but follows an elliptical path
"""

moveBindings = {
    'w': (0, 0, 1, 0),   # Z+
    's': (0, 0, -1, 0),  # Z-
    'a': (0, 0, 0, -1),  # Yaw+
    'd': (0, 0, 0, 1),   # Yaw-
    '\x1b[A': (0, 1, 0, 0),  # Up Arrow
    '\x1b[B': (0, -1, 0, 0), # Down Arrow
    '\x1b[C': (-1, 0, 0, 0), # Right Arrow
    '\x1b[D': (1, 0, 0, 0),  # Left Arrow
}

speedBindings = {
    # Reserved if you want to add speed/turn adjustments in the future
}

# Global variables to store current position and orientation
current_x = 0.0
current_y = 0.0
current_z = 0.0
current_yaw = 0.0
position_initialized = False

# Create a lock for thread safety when accessing position data
position_lock = threading.Lock()

# Function to replace tf_transformations.euler_from_quaternion
def euler_from_quaternion(quaternion):
    """
    Convert quaternion to euler angles (roll, pitch, yaw)
    """
    # Use transforms3d directly to avoid the np.float issue
    return transforms3d.euler.quat2euler([quaternion[3], quaternion[0], quaternion[1], quaternion[2]], 'rzyx')

class DroneControlNode(Node):
    def __init__(self):
        super().__init__('teleop_twist_keyboard')
        
        qos_profile = QoSProfile(
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=10
        )
        
        # Publishers
        self.pub = self.create_publisher(geometry_msgs.msg.Twist, '/offboard_velocity_cmd', qos_profile)
        self.arm_pub = self.create_publisher(std_msgs.msg.Bool, '/arm_message', qos_profile)
        
        # Updated to use PX4's VehicleOdometry message type
        self.odom_sub = self.create_subscription(
            VehicleOdometry,
            '/fmu/out/vehicle_odometry',  # PX4 provides odometry on this topic
            self.odom_callback,
            qos_profile)
        
        # Updated to use PX4's VehicleStatus message type
        self.status_sub = self.create_subscription(
            VehicleStatus,
            '/fmu/out/vehicle_status',
            self.status_callback,
            qos_profile)
        
        # Initialize status variables
        self.armed = False
        self.flight_mode = "MANUAL"
        self.last_position_update = time.time()
        
        # Add a logger for debugging
        self.get_logger().info("DroneControlNode initialized. Waiting for position data...")
    
    def odom_callback(self, msg):
        """
        Callback function to update current position and orientation using PX4's VehicleOdometry message
        """
        global current_x, current_y, current_z, current_yaw, position_initialized
        
        with position_lock:
            # Extract position from PX4's VehicleOdometry
            current_x = msg.position[0]
            current_y = msg.position[1]
            current_z = msg.position[2]
            
            # Extract orientation
            if hasattr(msg, 'q'):
                # If quaternion is available
                orientation_list = [msg.q[1], msg.q[2], msg.q[3], msg.q[0]]  # Convert to [x, y, z, w]
                _, _, current_yaw = euler_from_quaternion(orientation_list)
            elif hasattr(msg, 'yaw'):
                # If euler angles are directly available
                current_yaw = msg.yaw
            
            self.last_position_update = time.time()
            
            if not position_initialized:
                self.get_logger().info(f"Position data received: ({current_x:.2f}, {current_y:.2f}, {current_z:.2f}), Yaw: {current_yaw:.2f}")
            
            position_initialized = True
            
    def status_callback(self, msg):
        """
        Callback to receive vehicle status updates using PX4's VehicleStatus message
        """
        try:
            previous_armed = self.armed
            # 2 is typically ARMED in PX4
            self.armed = (msg.arming_state == 2)
            
            # Extract flight mode - depends on PX4's specific enum values
            if msg.nav_state == 14:  # Example value for OFFBOARD
                self.flight_mode = "OFFBOARD"
            else:
                self.flight_mode = "MANUAL"  # Default to manual for all other states
            
            # Log state changes
            if self.armed != previous_armed:
                self.get_logger().info(f"Drone is now {'ARMED' if self.armed else 'DISARMED'}")
                
        except Exception as e:
            self.get_logger().error(f"Error parsing status message: {e}")
    
    def is_position_stale(self, timeout=5.0):
        """Check if position data is stale (no updates within timeout period)"""
        return (time.time() - self.last_position_update) > timeout

def getKey(settings, timeout=None):
    """
    A modified getKey() function that can work in non-blocking mode using a timeout.
    On Windows, it uses msvcrt.kbhit(), while on Unix it uses select.select.
    """
    if sys.platform == 'win32':
        import msvcrt
        start = time.time()
        while True:
            if msvcrt.kbhit():
                return msvcrt.getwch()
            if timeout is not None and (time.time() - start) > timeout:
                return ''
            time.sleep(0.01)
    else:
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], timeout)
        if rlist:
            key = sys.stdin.read(1)
            if key == '\x1b':  # possible arrow key
                if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
                    key += sys.stdin.read(2)
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
            return key
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        return ''

def saveTerminalSettings():
    if sys.platform == 'win32':
        return None
    return termios.tcgetattr(sys.stdin)

def restoreTerminalSettings(old_settings):
    if sys.platform == 'win32':
        return
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)

def vels(speed, turn):
    return 'currently:\tspeed %s\tturn %s ' % (speed, turn)

def arm_drone(arm_pub, arm_state=True):
    """
    Arms or disarms the drone
    """
    arm_msg = std_msgs.msg.Bool()
    arm_msg.data = arm_state
    arm_pub.publish(arm_msg)
    print(f"Drone {'armed' if arm_state else 'disarmed'}")
    # Give time for the arming command to take effect
    time.sleep(2.0)
    return arm_state

def wait_for_motor_spinup(duration=10):
    """
    Wait for motors to reach maximum speed (arming time set to 10 seconds).
    """
    print(f"Waiting {duration} seconds for motors to reach maximum speed...")
    for i in range(duration, 0, -1):
        print(f"Motor spinup: {i} seconds remaining...")
        time.sleep(1.0)
    print("Motors ready!")

def move_to_position(pub, target_x, target_y, target_z, duration=20, rate=10, use_position_feedback=True):
    """
    Move the drone to a specific position using velocity commands with position feedback
    Will use open-loop control if position feedback is disabled or unavailable
    """
    global current_x, current_y, current_z, position_initialized
    
    # Determine if we can use position feedback
    can_use_feedback = use_position_feedback and position_initialized
    
    # PID control parameters
    kp = 0.8
    ki = 0.05
    kd = 0.2
    
    twist = geometry_msgs.msg.Twist()
    start_time = time.time()
    last_time = start_time
    
    # Error integrals and last errors for PID control
    x_integral, y_integral, z_integral = 0.0, 0.0, 0.0
    x_last_error, y_last_error, z_last_error = 0.0, 0.0, 0.0
    
    # Position threshold for considering "arrived"
    position_threshold = 0.3  # meters
    
    # Max allowed time to prevent infinite loops
    max_duration = duration * 1.5
    
    if can_use_feedback:
        with position_lock:
            current_pos_x = current_x
            current_pos_y = current_y
            current_pos_z = current_z
    else:
        # If no position feedback, assume starting at origin and move open-loop
        current_pos_x = 0.0
        current_pos_y = 0.0
        current_pos_z = 0.0
    
    print(f"Moving {'with position feedback' if can_use_feedback else 'WITHOUT position feedback'}")
    print(f"Moving from estimated position ({current_pos_x:.2f}, {current_pos_y:.2f}, {current_pos_z:.2f}) to target: ({target_x:.2f}, {target_y:.2f}, {target_z:.2f})")
    
    # For open-loop control
    if not can_use_feedback:
        dx = target_x - current_pos_x
        dy = target_y - current_pos_y
        dz = target_z - current_pos_z
        distance = math.sqrt(dx*dx + dy*dy + dz*dz)
        
        max_vel = 1.0  # m/s
        time_needed = distance / max_vel
        
        if distance > 0:
            vx = dx / distance * max_vel
            vy = dy / distance * max_vel
            vz = dz / distance * max_vel
        else:
            vx, vy, vz = 0.0, 0.0, 0.0
        
        print(f"Open-loop control: Moving at velocity ({vx:.2f}, {vy:.2f}, {vz:.2f}) for {time_needed:.2f} seconds")
        
        twist.linear.x = vx
        twist.linear.y = vy
        twist.linear.z = vz
        
        move_start = time.time()
        while (time.time() - move_start) < time_needed:
            pub.publish(twist)
            time.sleep(0.1)
            
            if not can_use_feedback and position_initialized:
                print("Position data now available! Switching to feedback control.")
                can_use_feedback = True
                break
        
        twist.linear.x = 0.0
        twist.linear.y = 0.0
        twist.linear.z = 0.0
        pub.publish(twist)
        
        if not can_use_feedback:
            print(f"Target position reached (open-loop estimate)")
            return True
    
    # Continue with closed-loop control if position feedback is available
    arrived = False
    while not arrived and (time.time() - start_time) < max_duration:
        if position_initialized:
            with position_lock:
                current_pos_x = current_x
                current_pos_y = current_y
                current_pos_z = current_z
        
        x_error = target_x - current_pos_x
        y_error = target_y - current_pos_y
        z_error = target_z - current_pos_z
        
        if (abs(x_error) < position_threshold and 
            abs(y_error) < position_threshold and 
            abs(z_error) < position_threshold):
            print(f"Target position reached: ({current_pos_x:.2f}, {current_pos_y:.2f}, {current_pos_z:.2f})")
            arrived = True
            break
        
        current_time = time.time()
        dt = current_time - last_time
        last_time = current_time
        
        x_integral += x_error * dt
        y_integral += y_error * dt
        z_integral += z_error * dt
        
        if dt > 0:
            x_derivative = (x_error - x_last_error) / dt
            y_derivative = (y_error - y_last_error) / dt
            z_derivative = (z_error - z_last_error) / dt
        else:
            x_derivative = 0
            y_derivative = 0
            z_derivative = 0
        
        x_last_error = x_error
        y_last_error = y_error
        z_last_error = z_error
        
        twist.linear.x = kp * x_error + ki * x_integral + kd * x_derivative
        twist.linear.y = kp * y_error + ki * y_integral + kd * y_derivative
        twist.linear.z = kp * z_error + ki * z_integral + kd * z_derivative
        
        max_vel = 2.0
        twist.linear.x = max(min(twist.linear.x, max_vel), -max_vel)
        twist.linear.y = max(min(twist.linear.y, max_vel), -max_vel)
        twist.linear.z = max(min(twist.linear.z, max_vel), -max_vel)
        
        pub.publish(twist)
        
        time.sleep(1.0 / rate)
        
        print(f"Moving - Current: ({current_pos_x:.2f}, {current_pos_y:.2f}, {current_pos_z:.2f}), " +
              f"Error: ({x_error:.2f}, {y_error:.2f}, {z_error:.2f}), " +
              f"Velocity: ({twist.linear.x:.2f}, {twist.linear.y:.2f}, {twist.linear.z:.2f})")
    
    twist.linear.x = 0.0
    twist.linear.y = 0.0
    twist.linear.z = 0.0
    pub.publish(twist)
    
    if not arrived and can_use_feedback:
        print(f"Warning: Timed out before reaching target position. Current position: ({current_pos_x:.2f}, {current_pos_y:.2f}, {current_pos_z:.2f})")
    
    return arrived

def circular_flight_mode(pub, arm_pub, settings, arm_toggle):
    """
    Enters circular flight mode around the building with position feedback if available:
      1. Automatically arms the drone if not armed
      2. Move to a position 5m above the ground directly above current position (reduced from 10m)
      3. Move to the house center at 5m height (reduced from 10m)
      4. Continuously executes a true circular flight pattern with larger radius
    """
    global current_x, current_y, current_z, current_yaw, position_initialized
    
    twist = geometry_msgs.msg.Twist()
    
    # House center position from the world file
    house_x = -8.28737
    house_y = 6.73763
    house_z = 0.0
    
    # Increase radius by 50% for wider circular path
    radius = math.sqrt(house_x**2 + house_y**2) * 1.5
    print(f"[Circular Mode] Distance from origin to house (radius): {radius:.2f}m")
    
    # Lower target height from 10m to 5m
    target_height = 5.0
    
    # Arm if not armed
    if not arm_toggle:
        print("[Circular Mode] Arming drone automatically...")
        arm_toggle = arm_drone(arm_pub, True)
        wait_for_motor_spinup(10)
    
    if position_initialized:
        with position_lock:
            start_x = current_x
            start_y = current_y
        
        print(f"[Circular Mode] Moving to {target_height}m height...")
        move_to_position(pub, start_x, start_y, target_height)
        
        target_x = house_x
        target_y = house_y
        target_z = house_z + target_height
        
        print(f"\n[Circular Mode] Moving to position above the house ({target_x:.2f}, {target_y:.2f}, {target_z:.2f})...")
        move_to_position(pub, target_x, target_y, target_z)
    else:
        print(f"[Circular Mode] No position data available. Moving directly to {target_height}m height...")
        twist.linear.x = 0.0
        twist.linear.y = 0.0
        twist.linear.z = 0.5  # Reduced ascent velocity for better control
        
        ascend_duration = target_height * 2  # Adjust duration based on target height
        start_time = time.time()
        while (time.time() - start_time) < ascend_duration:
            pub.publish(twist)
            time.sleep(0.1)
            
            if not position_initialized:
                key = getKey(settings, timeout=0.01)
                if key == 'p':
                    print("[Circular Mode] 'p' pressed. Exiting circular mode.")
                    twist.linear.z = 0.0
                    pub.publish(twist)
                    return arm_toggle
    
    # Reduced rotation speed for larger radius
    omega = 0.1
    print(f"[Circular Mode] Starting circular flight pattern with radius={radius:.2f}m at {target_height}m height...")
    
    start_time = time.time()
    rate = 10
    
    kp_pos = 1.0
    kp_yaw = 1.5
    
    # Stronger height control to maintain consistent altitude
    kp_height = 1.5
    
    while True:
        key = getKey(settings, timeout=0.01)
        if key == 'p':
            print("[Circular Mode] 'p' pressed. Exiting circular mode.")
            break
            
        t = time.time() - start_time
        angle = omega * t
        
        desired_x = house_x + radius * math.cos(angle)
        desired_y = house_y + radius * math.sin(angle)
        desired_z = house_z + target_height  # Maintain consistent lower height
        
        if position_initialized:
            with position_lock:
                current_pos_x = current_x
                current_pos_y = current_y
                current_pos_z = current_z
                current_pos_yaw = current_yaw
            
            x_error = desired_x - current_pos_x
            y_error = desired_y - current_pos_y
            z_error = desired_z - current_pos_z
            
            twist.linear.x = kp_pos * x_error
            twist.linear.y = kp_pos * y_error
            # Use stronger height control to keep drone at consistent altitude
            twist.linear.z = kp_height * z_error
            
            dx = house_x - current_pos_x
            dy = house_y - current_pos_y
            desired_yaw = math.atan2(dy, dx)
            
            yaw_error = desired_yaw - current_pos_yaw
            if yaw_error > math.pi:
                yaw_error -= 2 * math.pi
            elif yaw_error < -math.pi:
                yaw_error += 2 * math.pi
            
            twist.angular.z = kp_yaw * yaw_error
            
            current_pos_str = f"Current: ({current_pos_x:.2f}, {current_pos_y:.2f}, {current_pos_z:.2f})"
            yaw_str = f"Yaw: {current_pos_yaw:.2f}/{desired_yaw:.2f}"
        else:
            vx = -omega * radius * math.sin(angle)
            vy = omega * radius * math.cos(angle)
            vz = 0.0  # Zero vertical velocity to maintain height
            
            twist.linear.x = vx
            twist.linear.y = vy
            twist.linear.z = vz
            
            twist.angular.z = omega
            
            current_pos_str = "Position unknown"
            yaw_str = "Yaw unknown"
        
        max_lin_vel = 2.0
        max_ang_vel = 1.0
        twist.linear.x = max(min(twist.linear.x, max_lin_vel), -max_lin_vel)
        twist.linear.y = max(min(twist.linear.y, max_lin_vel), -max_lin_vel)
        twist.linear.z = max(min(twist.linear.z, max_lin_vel), -max_lin_vel)
        twist.angular.z = max(min(twist.angular.z, max_ang_vel), -max_ang_vel)
        
        pub.publish(twist)
        print(f"Circular Flight - {current_pos_str}, " +
              f"Desired: ({desired_x:.2f}, {desired_y:.2f}, {desired_z:.2f}), " +
              f"{yaw_str}, " +
              f"Vel: ({twist.linear.x:.2f}, {twist.linear.y:.2f}, {twist.linear.z:.2f})")
        
        time.sleep(1.0 / rate)
    
    twist.linear.x = 0.0
    twist.linear.y = 0.0
    twist.linear.z = 0.0
    twist.angular.x = 0.0
    twist.angular.y = 0.0
    twist.angular.z = 0.0
    pub.publish(twist)
    
    return arm_toggle

def elliptical_flight_mode(pub, arm_pub, settings, arm_toggle):
    """
    Enters elliptical flight mode with or without position feedback:
      1. Automatically arms the drone if not armed
      2. Move to a position 5m above the ground (reduced from 10m)
      3. Continuously executes an elliptical flight pattern with larger axes
    """
    global current_x, current_y, current_z, current_yaw, position_initialized
    
    twist = geometry_msgs.msg.Twist()
    
    ellipse_center_x = -4.0
    ellipse_center_y = 4.0
    ellipse_z = 5.0  # Reduced from 10m to 5m
    
    # Increase the ellipse size for wider path
    semi_major = 18.0  # Increased from 12.0
    semi_minor = 12.0  # Increased from 8.0
    
    print(f"[Elliptical Mode] Starting elliptical pattern with semi-major axis: {semi_major:.2f}m, semi-minor axis: {semi_minor:.2f}m")
    
    if not arm_toggle:
        print("[Elliptical Mode] Arming drone automatically...")
        arm_toggle = arm_drone(arm_pub, True)
        wait_for_motor_spinup(10)
    
    if position_initialized:
        with position_lock:
            start_x = current_x
            start_y = current_y
        
        print("[Elliptical Mode] Moving to target height...")
        move_to_position(pub, start_x, start_y, ellipse_z)
        
        ellipse_start_x = ellipse_center_x + semi_major
        ellipse_start_y = ellipse_center_y
        
        print(f"\n[Elliptical Mode] Moving to ellipse starting point ({ellipse_start_x:.2f}, {ellipse_start_y:.2f}, {ellipse_z:.2f})...")
        move_to_position(pub, ellipse_start_x, ellipse_start_y, ellipse_z)
    else:
        print("[Elliptical Mode] No position data available. Moving directly to target height...")
        twist.linear.x = 0.0
        twist.linear.y = 0.0
        twist.linear.z = 0.5  # Reduced ascent velocity for better control
        
        ascend_duration = ellipse_z * 2  # Adjust duration based on target height
        start_time = time.time()
        while (time.time() - start_time) < ascend_duration:
            pub.publish(twist)
            time.sleep(0.1)
            
            key = getKey(settings, timeout=0.01)
            if key == 'e':
                print("[Elliptical Mode] 'e' pressed. Exiting elliptical mode.")
                twist.linear.z = 0.0
                pub.publish(twist)
                return arm_toggle
    
    # Reduced rotation speed for larger pattern
    omega = 0.08
    print(f"[Elliptical Mode] Starting elliptical flight pattern...")
    
    start_time = time.time()
    rate = 10
    
    kp_pos = 1.0
    kp_yaw = 1.5
    
    # Stronger height control
    kp_height = 1.5
    
    while True:
        key = getKey(settings, timeout=0.01)
        if key == 'e':
            print("[Elliptical Mode] 'e' pressed. Exiting elliptical mode.")
            break
            
        t = time.time() - start_time
        angle = omega * t
        
        desired_x = ellipse_center_x + semi_major * math.cos(angle)
        desired_y = ellipse_center_y + semi_minor * math.sin(angle)
        desired_z = ellipse_z  # Maintain consistent lower height
        
        if position_initialized:
            with position_lock:
                current_pos_x = current_x
                current_pos_y = current_y
                current_pos_z = current_z
                current_pos_yaw = current_yaw
            
            x_error = desired_x - current_pos_x
            y_error = desired_y - current_pos_y
            z_error = desired_z - current_pos_z
            
            twist.linear.x = kp_pos * x_error
            twist.linear.y = kp_pos * y_error
            # Use stronger height control
            twist.linear.z = kp_height * z_error
            
            dx = ellipse_center_x - current_pos_x
            dy = ellipse_center_y - current_pos_y
            desired_yaw = math.atan2(dy, dx)
            
            yaw_error = desired_yaw - current_pos_yaw
            if yaw_error > math.pi:
                yaw_error -= 2 * math.pi
            elif yaw_error < -math.pi:
                yaw_error += 2 * math.pi
            
            twist.angular.z = kp_yaw * yaw_error
            
            current_pos_str = f"Current: ({current_pos_x:.2f}, {current_pos_y:.2f}, {current_pos_z:.2f})"
            yaw_str = f"Yaw: {current_pos_yaw:.2f}/{desired_yaw:.2f}"
        else:
            vx = -omega * semi_major * math.sin(angle)
            vy = omega * semi_minor * math.cos(angle)
            vz = 0.0  # Zero vertical velocity to maintain height
            
            twist.linear.x = vx
            twist.linear.y = vy
            twist.linear.z = vz
            
            twist.angular.z = omega
            
            current_pos_str = "Position unknown"
            yaw_str = "Yaw unknown"
        
        max_lin_vel = 2.0
        max_ang_vel = 1.0
        twist.linear.x = max(min(twist.linear.x, max_lin_vel), -max_lin_vel)
        twist.linear.y = max(min(twist.linear.y, max_lin_vel), -max_lin_vel)
        twist.linear.z = max(min(twist.linear.z, max_lin_vel), -max_lin_vel)
        twist.angular.z = max(min(twist.angular.z, max_ang_vel), -max_ang_vel)
        
        pub.publish(twist)
        print(f"Elliptical Flight - {current_pos_str}, " +
              f"Desired: ({desired_x:.2f}, {desired_y:.2f}, {desired_z:.2f}), " +
              f"{yaw_str}, " +
              f"Vel: ({twist.linear.x:.2f}, {twist.linear.y:.2f}, {twist.linear.z:.2f})")
        
        time.sleep(1.0 / rate)
    
    twist.linear.x = 0.0
    twist.linear.y = 0.0
    twist.linear.z = 0.0
    twist.angular.x = 0.0
    twist.angular.y = 0.0
    twist.angular.z = 0.0
    pub.publish(twist)
    
    return arm_toggle
def estimate_position_from_velocity(start_x, start_y, start_z, vx, vy, vz, dt):
    """
    Estimates new position based on velocity and time delta
    Used when position feedback is not available
    """
    new_x = start_x + vx * dt
    new_y = start_y + vy * dt
    new_z = start_z + vz * dt
    return new_x, new_y, new_z

def ros_spin_thread(node):
    """Thread function to handle ROS callbacks"""
    while rclpy.ok():
        rclpy.spin_once(node, timeout_sec=0.1)
        time.sleep(0.01)  # Small sleep to reduce CPU usage

def main():
    settings = saveTerminalSettings()

    rclpy.init()
    node = DroneControlNode()
    
    spin_thread = threading.Thread(target=ros_spin_thread, args=(node,))
    spin_thread.daemon = True
    spin_thread.start()

    arm_toggle = False
    speed = 0.5
    turn = 0.2
    x_val = 0.0
    y_val = 0.0
    z_val = 0.0
    yaw_val = 0.0
    
    estimated_x = 0.0
    estimated_y = 0.0
    estimated_z = 0.0
    last_estimation_time = time.time()

    print(msg)
    print(vels(speed, turn))
    print("Waiting for initial position data...")
    
    timeout = 5.0
    start_time = time.time()
    while not position_initialized and (time.time() - start_time) < timeout:
        time.sleep(0.1)
    
    if position_initialized:
        with position_lock:
            print(f"Current position: ({current_x:.2f}, {current_y:.2f}, {current_z:.2f}), Yaw: {current_yaw:.2f}")
    else:
        print("Warning: No position data received. Operating in open-loop mode.")
    
    try:
        while True:
            key = getKey(settings, timeout=0.1)
            
            if position_initialized:
                with position_lock:
                    current_pos_x = current_x
                    current_pos_y = current_y
                    current_pos_z = current_z
                    current_pos_yaw = current_yaw
                current_pos_str = f"Position: ({current_pos_x:.2f}, {current_pos_y:.2f}, {current_pos_z:.2f})"
                
                estimated_x = current_pos_x
                estimated_y = current_pos_y
                estimated_z = current_pos_z
            else:
                current_time = time.time()
                dt = current_time - last_estimation_time
                if dt > 0:
                    estimated_x, estimated_y, estimated_z = estimate_position_from_velocity(
                        estimated_x, estimated_y, estimated_z, 
                        x_val, y_val, z_val, dt)
                    last_estimation_time = current_time
                
                current_pos_str = f"Estimated position: ({estimated_x:.2f}, {estimated_y:.2f}, {estimated_z:.2f}) [NO FEEDBACK]"
            
            if key == 'p':
                print("Toggling circular flight mode...")
                arm_toggle = circular_flight_mode(node.pub, node.arm_pub, settings, arm_toggle)
                x_val = 0.0
                y_val = 0.0
                z_val = 0.0
                yaw_val = 0.0
                last_estimation_time = time.time()
                continue
            
            elif key == 'e':
                print("Toggling elliptical flight mode...")
                arm_toggle = elliptical_flight_mode(node.pub, node.arm_pub, settings, arm_toggle)
                x_val = 0.0
                y_val = 0.0
                z_val = 0.0
                yaw_val = 0.0
                last_estimation_time = time.time()
                continue

            if key in moveBindings.keys():
                x = moveBindings[key][0]
                y = moveBindings[key][1]
                z = moveBindings[key][2]
                th = moveBindings[key][3]
            else:
                x = 0.0
                y = 0.0
                z = 0.0
                th = 0.0
                if key == '\x03':
                    break

            if key == ' ':
                arm_toggle = arm_drone(node.arm_pub, not arm_toggle)

            twist = geometry_msgs.msg.Twist()
            x_val = max(min((x * speed) + x_val, 2.0), -2.0)
            y_val = max(min((y * speed) + y_val, 2.0), -2.0)
            z_val = max(min((z * speed) + z_val, 2.0), -2.0)
            yaw_val = max(min((th * turn) + yaw_val, 2.0), -2.0)
            
            if x == 0:
                x_val *= 0.95
            if y == 0:
                y_val *= 0.95
            if z == 0:
                z_val *= 0.95
            if th == 0:
                yaw_val *= 0.95
            
            if abs(x_val) < 0.05:
                x_val = 0.0
            if abs(y_val) < 0.05:
                y_val = 0.0
            if abs(z_val) < 0.05:
                z_val = 0.0
            if abs(yaw_val) < 0.05:
                yaw_val = 0.0
                
            twist.linear.x = x_val
            twist.linear.y = y_val
            twist.linear.z = z_val
            twist.angular.x = 0.0
            twist.angular.y = 0.0
            twist.angular.z = yaw_val
            node.pub.publish(twist)
            
            position_status = "POSITION OK" if position_initialized else "NO POSITION DATA"
            arm_status = "ARMED" if arm_toggle else "DISARMED"
            status_msg = (f"Manual Control - X: {twist.linear.x:.2f}, Y: {twist.linear.y:.2f}, Z: {twist.linear.z:.2f}, "
                          f"Yaw: {twist.angular.z:.2f}, {current_pos_str}, Status: {position_status}, {arm_status}")
            print(status_msg)

    except Exception as e:
        print(f"Error: {e}")
    finally:
        twist = geometry_msgs.msg.Twist()
        twist.linear.x = 0.0
        twist.linear.y = 0.0
        twist.linear.z = 0.0
        twist.angular.x = 0.0
        twist.angular.y = 0.0
        twist.angular.z = 0.0
        node.pub.publish(twist)
        restoreTerminalSettings(settings)
        
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

