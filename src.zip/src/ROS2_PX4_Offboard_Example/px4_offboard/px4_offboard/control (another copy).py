#!/usr/bin/env python3
import sys
import time
import math
import select

import geometry_msgs.msg
import rclpy
import std_msgs.msg
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy, QoSDurabilityPolicy

if sys.platform == 'win32':
    import msvcrt
else:
    import termios
    import tty

msg = """
This node takes keypresses from the keyboard and publishes them
as Twist messages.
Using the arrow keys and WASD you have Mode 2 RC controls.
W: Up
S: Down
A: Yaw Left
D: Yaw Right
Up Arrow: Pitch Forward
Down Arrow: Pitch Backward
Left Arrow: Roll Left
Right Arrow: Roll Right

Press SPACE to arm/disarm the drone manually
Press 'p' to toggle elliptical flight mode around the house (start/stop)
    - This will automatically arm the drone
    - The drone will first move to 10m height above the house
    - Then it will follow an elliptical path around the house
"""

moveBindings = {
    'w': (0, 0, 1, 0),   # Z+
    's': (0, 0, -1, 0),  # Z-
    'a': (0, 0, 0, -1),  # Yaw+
    'd': (0, 0, 0, 1),   # Yaw-
    '\x1b[A': (0, 1, 0, 0),  # Up Arrow
    '\x1b[B': (0, -1, 0, 0), # Down Arrow
    '\x1b[C': (-1, 0, 0, 0), # Right Arrow
    '\x1b[D': (1, 0, 0, 0),  # Left Arrow
}

speedBindings = {
    # 'q': (1.1, 1.1),
    # 'z': (.9, .9),
    # 'w': (1.1, 1),
    # 'x': (.9, 1),
    # 'e': (1, 1.1),
    # 'c': (1, .9),
}

def getKey(settings, timeout=None):
    """
    A modified getKey() function that can work in non-blocking mode using a timeout.
    On Windows, it uses msvcrt.kbhit(), while on Unix it uses select.select.
    """
    if sys.platform == 'win32':
        start = time.time()
        while True:
            if msvcrt.kbhit():
                return msvcrt.getwch()
            if timeout is not None and (time.time() - start) > timeout:
                return ''
            time.sleep(0.01)
    else:
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], timeout)
        if rlist:
            key = sys.stdin.read(1)
            if key == '\x1b':  # possible arrow key
                if sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
                    key += sys.stdin.read(2)
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
            return key
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        return ''

def saveTerminalSettings():
    if sys.platform == 'win32':
        return None
    return termios.tcgetattr(sys.stdin)

def restoreTerminalSettings(old_settings):
    if sys.platform == 'win32':
        return
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)

def vels(speed, turn):
    return 'currently:\tspeed %s\tturn %s ' % (speed, turn)

def arm_drone(arm_pub, arm_state=True):
    """
    Arms or disarms the drone
    """
    arm_msg = std_msgs.msg.Bool()
    arm_msg.data = arm_state
    arm_pub.publish(arm_msg)
    print(f"Drone {'armed' if arm_state else 'disarmed'}")
    # Give time for the arming command to take effect
    time.sleep(2.0)
    return arm_state

def wait_for_motor_spinup(duration=5):
    """
    Wait for motors to reach maximum speed
    """
    print(f"Waiting {duration} seconds for motors to reach maximum speed...")
    for i in range(duration, 0, -1):
        print(f"Motor spinup: {i} seconds remaining...")
        time.sleep(1.0)
    print("Motors ready!")

def move_to_position(pub, target_x, target_y, target_z, duration=20, rate=10):
    """
    Move the drone to a specific position using velocity commands
    """
    # Calculate the velocity needed to reach the target in the given duration
    twist = geometry_msgs.msg.Twist()
    start_time = time.time()
    elapsed = 0
    
    # Get current position (this is a simplification, in a real system you'd use odometry feedback)
    current_x, current_y, current_z = 0, 0, 0  # Assuming drone starts at origin
    
    while elapsed < duration:
        # Recalculate velocity based on remaining distance and time
        remaining_time = max(duration - elapsed, 1.0)
        
        twist.linear.x = (target_x - current_x) / remaining_time
        twist.linear.y = (target_y - current_y) / remaining_time
        twist.linear.z = (target_z - current_z) / remaining_time
        
        # Update current position estimate
        current_x += twist.linear.x * (1.0 / rate)
        current_y += twist.linear.y * (1.0 / rate)
        current_z += twist.linear.z * (1.0 / rate)
        
        # Publish velocity command
        pub.publish(twist)
        
        # Sleep to maintain the desired rate
        time.sleep(1.0 / rate)
        elapsed = time.time() - start_time
        
        print(f"Moving to position - X: {current_x:.2f}/{target_x}, Y: {current_y:.2f}/{target_y}, Z: {current_z:.2f}/{target_z}")
    
    # Stop the drone when position is reached
    twist.linear.x = 0.0
    twist.linear.y = 0.0
    twist.linear.z = 0.0
    pub.publish(twist)
    print(f"Reached target position: ({current_x:.2f}, {current_y:.2f}, {current_z:.2f})")
    return current_x, current_y, current_z

def elliptical_mode(pub, arm_pub, settings, arm_toggle):
    """
    Enters elliptical flight mode around the building:
      1. Automatically arms the drone if not armed
      2. Move to a position 10m above the ground directly above current position
      3. Move to the house center at 10m height
      4. Continuously executes a circular flight pattern with radius = distance from origin to house
    """
    twist = geometry_msgs.msg.Twist()
    
    # House center position from the world file
    house_x = -8.28737
    house_y = 6.73763
    house_z = 0.0
    
    # First arm the drone if it's not armed
    if not arm_toggle:
        print("[Elliptical Mode] Arming drone automatically...")
        arm_toggle = arm_drone(arm_pub, True)
        # Wait for motors to spin up to maximum speed
        wait_for_motor_spinup(5)
    
    # Step 1: Move to 10m height directly above current position
    print("[Elliptical Mode] Moving to 10m height...")
    current_x, current_y, _ = move_to_position(pub, 0, 0, 10.0)
    
    # Step 2: Move to the position above the house center
    target_x = house_x
    target_y = house_y
    target_z = house_z + 10.0
    
    print(f"\n[Elliptical Mode] Moving to position above the house ({target_x}, {target_y}, {target_z})...")
    current_x, current_y, current_z = move_to_position(pub, target_x, target_y, target_z)
    
    # Calculate the distance from origin to house center = radius for circular flight
    distance_to_house = math.sqrt(house_x**2 + house_y**2)
    print(f"[Elliptical Mode] Distance to house center (radius): {distance_to_house:.2f}m")
    
    # Circle flight parameters - using distance to origin as the radius
    radius = distance_to_house
    omega = 0.15  # angular speed in rad/s (adjust for desired speed)
    
    print(f"[Elliptical Mode] Starting circular flight pattern (radius={radius:.2f}m)...")
    
    # Circle flight phase: continue until 'p' is pressed
    start_time = time.time()
    rate = 10  # Hz
    
    # Calculate the angle to the house from the origin (for reference)
    house_angle = math.atan2(house_y, house_x)
    print(f"[Elliptical Mode] House angle from origin: {math.degrees(house_angle):.2f} degrees")
    
    while True:
        # Check for key press to exit elliptical mode
        key = getKey(settings, timeout=0.01)
        if key == 'p':
            print("[Elliptical Mode] 'p' pressed. Exiting elliptical mode.")
            break
            
        t = time.time() - start_time
        
        # Compute position on the circle centered at origin with radius = distance_to_house
        angle = omega * t
        
        # Calculate the position on the circle - use house as center
        circle_x = radius * math.cos(angle)
        circle_y = radius * math.sin(angle)
        circle_z = target_z  # maintain altitude
        
        # Calculate velocity to reach the next position on the circle
        # These are the derivatives of the position equations
        twist.linear.x = -radius * omega * math.sin(angle)
        twist.linear.y = radius * omega * math.cos(angle)
        twist.linear.z = 0.0  # maintain altitude
        
        # Make the drone always face toward the house center
        dx = house_x - circle_x
        dy = house_y - circle_y
        desired_yaw = math.atan2(dy, dx)
        
        # Set angular velocity to face the house (simple P controller)
        twist.angular.x = 0.0
        twist.angular.y = 0.0
        twist.angular.z = desired_yaw * 0.5  # Scale the yaw command
        
        pub.publish(twist)
        print(f"Circular Flight - Pos: ({circle_x:.2f}, {circle_y:.2f}, {circle_z:.2f}), " +
              f"Vel: ({twist.linear.x:.2f}, {twist.linear.y:.2f}, {twist.linear.z:.2f}), " +
              f"Facing house at ({house_x:.2f}, {house_y:.2f})")
        
        time.sleep(1.0 / rate)
    
    # Stop the drone when exiting elliptical mode
    twist.linear.x = 0.0
    twist.linear.y = 0.0
    twist.linear.z = 0.0
    twist.angular.x = 0.0
    twist.angular.y = 0.0
    twist.angular.z = 0.0
    pub.publish(twist)
    
    return arm_toggle

def main():
    settings = saveTerminalSettings()

    rclpy.init()
    node = rclpy.create_node('teleop_twist_keyboard')

    qos_profile = QoSProfile(
        reliability=QoSReliabilityPolicy.BEST_EFFORT,
        durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
        history=QoSHistoryPolicy.KEEP_LAST,
        depth=10
    )

    pub = node.create_publisher(geometry_msgs.msg.Twist, '/offboard_velocity_cmd', qos_profile)
    arm_toggle = False
    arm_pub = node.create_publisher(std_msgs.msg.Bool, '/arm_message', qos_profile)

    speed = 0.5
    turn = 0.2
    x_val = 0.0
    y_val = 0.0
    z_val = 0.0
    yaw_val = 0.0

    print(msg)
    while True:
        # In manual mode, use a short timeout so we can poll frequently.
        key = getKey(settings, timeout=0.1)
        # Toggle elliptical mode if 'p' is pressed.
        if key == 'p':
            print("Toggling elliptical mode for house circling...")
            arm_toggle = elliptical_mode(pub, arm_pub, settings, arm_toggle)
            # Reset values after exiting elliptical mode
            x_val = 0.0
            y_val = 0.0
            z_val = 0.0
            yaw_val = 0.0
            # After exiting elliptical mode, resume manual control.
            continue

        # Process manual teleoperation commands.
        if key in moveBindings.keys():
            x = moveBindings[key][0]
            y = moveBindings[key][1]
            z = moveBindings[key][2]
            th = moveBindings[key][3]
        else:
            x = 0.0
            y = 0.0
            z = 0.0
            th = 0.0
            if key == '\x03':  # Ctrl+C to exit.
                break

        if key == ' ':  # Toggle arming/disarming on SPACE.
            arm_toggle = arm_drone(arm_pub, not arm_toggle)

        twist = geometry_msgs.msg.Twist()
        x_val = (x * speed) + x_val
        y_val = (y * speed) + y_val
        z_val = (z * speed) + z_val
        yaw_val = (th * turn) + yaw_val
        twist.linear.x = x_val
        twist.linear.y = y_val
        twist.linear.z = z_val
        twist.angular.x = 0.0
        twist.angular.y = 0.0
        twist.angular.z = yaw_val
        pub.publish(twist)
        print("Manual Control - X:", twist.linear.x,
              "Y:", twist.linear.y,
              "Z:", twist.linear.z,
              "Yaw:", twist.angular.z)

    # On exit, send a zero command.
    twist = geometry_msgs.msg.Twist()
    twist.linear.x = 0.0
    twist.linear.y = 0.0
    twist.linear.z = 0.0
    twist.angular.x = 0.0
    twist.angular.y = 0.0
    twist.angular.z = 0.0
    pub.publish(twist)
    restoreTerminalSettings(settings)

if __name__ == '__main__':
    main()
